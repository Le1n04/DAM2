/**
 * 
 */
/**
 * 
 */
module A005raton {
}