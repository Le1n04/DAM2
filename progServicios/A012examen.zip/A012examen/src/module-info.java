/**
 * 
 */
/**
 * 
 */
module A012examen {
}