/**
 * 
 */
/**
 * 
 */
module A008waitNotify {
}