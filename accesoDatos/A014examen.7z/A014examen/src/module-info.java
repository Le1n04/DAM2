/**
 * 
 */
/**
 * 
 */
module A014examen
{
	requires java.sql;
}